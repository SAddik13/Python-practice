for val in range(11):
	print(val)
else:
	print("Job done")



for num1 in range(3):
	for num2 in range(10, 14):
		print(num1, ",", num2)
print("And this is Nested For loop")
