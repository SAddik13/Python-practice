downloads = 999
print(downloads == 1000)
