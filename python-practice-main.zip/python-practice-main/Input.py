username = input("Enter username:")
print("Hello " + username)
