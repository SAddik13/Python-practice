available = True
print("Anyone Availabe?")
print(not available)

is_day = False
lights_on = not is_day
print("Daytime?")
print(is_day)

print("Lights on?")
print(lights_on)
