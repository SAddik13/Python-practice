Daysoftheweek = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
print("Day's Of The Week :-)")

print(Daysoftheweek [0])


print(Daysoftheweek[1])


print(Daysoftheweek[2])


print(Daysoftheweek[3])


print(Daysoftheweek[4])


print(Daysoftheweek[5])


print(Daysoftheweek[6])
