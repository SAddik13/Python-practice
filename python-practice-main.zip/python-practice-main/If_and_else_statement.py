num = 100
if num < 200:
    print("num is less than 200")
num = 22
if num % 2 == 0:
    print("Even Number")
else:
    print("Odd Number")
