x = 12
y = 3

print(x / y)

print("And")

x = 5
y = 3

print(x * y)
