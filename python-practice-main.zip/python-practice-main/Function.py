def add(num1, num2):
    return num1 + num2


sum1 = add(100, 200)
sum2 = add(8, 9)
print(sum1)
print(sum2)
