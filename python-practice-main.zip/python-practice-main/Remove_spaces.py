name = '  Ma Mosaddik  '

print (name.lstrip())


print (name.rstrip())


print (name.strip())
