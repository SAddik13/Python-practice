value_a = 2
value_b = 1
print(value_a <= value_b)

print("OR")

result = 1 >= 1
print(result)
