num = 100
str = "BeginnersBook"
print(num)
print(str)
