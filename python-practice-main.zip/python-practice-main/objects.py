class student:
        def __init__(self, roll, name):
                self.r = roll
                self.n = name
                print ((self.n))
                
#...       
stud1 = student(1, "SAddik")
stud2 = student(2, "SAddik2")

print ("Data successfully stored")
